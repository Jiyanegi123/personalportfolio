export const personalInfo = {
  name: "Sai Teja",
  role: "Full Stack Developer",
  tagline: "Passionate about creating innovative web solutions with expertise in MERN stack development.",
  location: "Hyderabad, India",
  email: "saiteja.contact@gmail.com",
  phone: "+91 9876543210",
  socialLinks: {
    github: "https://github.com/saiteja",
    linkedin: "https://linkedin.com/in/saiteja",
  }
};