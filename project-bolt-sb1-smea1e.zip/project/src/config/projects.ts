export const projects = [
  {
    title: "E-Learning Platform",
    description: "A comprehensive learning management system with video courses, quizzes, and progress tracking",
    image: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80",
    technologies: ["React", "Node.js", "MongoDB", "Express", "AWS S3"],
    githubLink: "https://github.com/saiteja/e-learning",
    liveLink: "https://e-learning-platform.com"
  },
  {
    title: "Real-time Chat Application",
    description: "Feature-rich chat application with real-time messaging, file sharing, and user presence",
    image: "https://images.unsplash.com/photo-1611746872915-64382b5c76da?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    technologies: ["React", "Socket.io", "Node.js", "MongoDB", "Redux"],
    githubLink: "https://github.com/saiteja/chat-app",
    liveLink: "https://chat-application.com"
  },
  {
    title: "Project Management Tool",
    description: "Collaborative project management tool with task tracking, team management, and analytics",
    image: "https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1476&q=80",
    technologies: ["Next.js", "TypeScript", "PostgreSQL", "Docker", "AWS"],
    githubLink: "https://github.com/saiteja/project-manager",
    liveLink: "https://project-management-tool.com"
  },
  {
    title: "E-Commerce Dashboard",
    description: "Administrative dashboard for managing products, orders, and customer data with analytics",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1415&q=80",
    technologies: ["React", "Material UI", "Node.js", "MySQL", "Redis"],
    githubLink: "https://github.com/saiteja/ecommerce-dashboard",
    liveLink: "https://ecommerce-dashboard.com"
  }
];