import { Code, Server, Database, Cog, Laptop, Cloud } from 'lucide-react';

export const skills = [
  {
    icon: Code,
    title: "Frontend Development",
    description: "React.js, Next.js, TypeScript, Redux"
  },
  {
    icon: Server,
    title: "Backend Development",
    description: "Node.js, Express.js, REST APIs"
  },
  {
    icon: Database,
    title: "Database Management",
    description: "MongoDB, MySQL, PostgreSQL"
  },
  {
    icon: Cloud,
    title: "Cloud Services",
    description: "AWS, Docker, CI/CD"
  },
  {
    icon: Cog,
    title: "Tools & Testing",
    description: "Git, Jest, Cypress"
  },
  {
    icon: Laptop,
    title: "Development Tools",
    description: "VS Code, Postman, npm"
  }
];