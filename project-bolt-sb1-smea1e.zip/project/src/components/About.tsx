import React from 'react';
import { motion } from 'framer-motion';
import { skills } from '../config/skills';
import { personalInfo } from '../config/personalInfo';

const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl font-bold text-center mb-12">About Me</h2>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.unsplash.com/photo-1571171637578-41bc2dd41cd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                alt="Developer working"
                className="rounded-lg shadow-lg"
              />
            </div>
            
            <div className="space-y-6">
              <p className="text-lg text-gray-600">
                As a Full Stack Developer with 3+ years of experience, I specialize in building scalable web applications 
                using the MERN stack. My expertise includes developing responsive user interfaces, RESTful APIs, and 
                managing database operations. I'm passionate about writing clean, efficient code and implementing best 
                practices in software development.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                {skills.map((skill, index) => (
                  <SkillCard
                    key={index}
                    icon={<skill.icon />}
                    title={skill.title}
                    description={skill.description}
                  />
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const SkillCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => (
  <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
    <div className="p-2 bg-gray-100 rounded-lg">
      {icon}
    </div>
    <div>
      <h3 className="font-semibold text-lg">{title}</h3>
      <p className="text-gray-600 text-sm">{description}</p>
    </div>
  </div>
);

export default About;